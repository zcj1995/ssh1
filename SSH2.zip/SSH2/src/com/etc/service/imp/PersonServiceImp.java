package com.etc.service.imp;

import java.util.ArrayList;
import java.util.List;

import com.etc.dao.IPersonDao;
import com.etc.dao.imp.PersonDaoImp;
import com.etc.entity.Person;
import com.etc.service.IPersonService;

public class PersonServiceImp implements IPersonService {

	private IPersonDao personDao;
	public IPersonDao getPersonDao() {
		return personDao;
	}

	public void setPersonDao(IPersonDao personDao) {
		this.personDao = personDao;
	}

	@Override
	public int add(Person user) {

		return personDao.add(user);
	}

	@Override
	public void update(Person user) {
		personDao.update(user);
	}

	@Override
	public void delete(int index) {
		personDao.delete(index);
	}

	@Override
	public Person getPerson(int index) {
		return personDao.getPerson(index);
	}

	@Override
	public List<Person> getPersons() {
		//手工方式
//		IPersonDao iPersonDao=new PersonDaoImp();
		
		return personDao.getPersons();
		
		
	}

}
