package com.etc.test;

import java.util.List;

import org.junit.Test;

import com.etc.entity.Person;
import com.etc.service.IPersonService;
import com.etc.service.imp.PersonServiceImp;

public class TestPersonAction {
	@Test
	public void test() {
		// service实现
		IPersonService iPersonService = new PersonServiceImp();
		// Dao实现
		List<Person> persons=iPersonService.getPersons();
		
		for (Person person : persons) {
			System.out.println(person);
		}
		
		
	}
}
