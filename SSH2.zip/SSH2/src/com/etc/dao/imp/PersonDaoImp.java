package com.etc.dao.imp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.etc.dao.IPersonDao;
import com.etc.entity.Person;

public class PersonDaoImp extends HibernateDaoSupport implements IPersonDao  {

	@Override
	public int add(Person user) {
		return (int) getHibernateTemplate().save(user);
	}

	@Override
	public void update(Person user) {
		getHibernateTemplate().update(user);
	}

	@Override
	public void delete(int index) {
		Object p = getHibernateTemplate().load(Person.class, index);
		getHibernateTemplate().delete(p);
	}

	@Override
	public Person getPerson(int index) {
		return this.getHibernateTemplate().get(Person.class, index);
	}

	@Override
	public List<Person> getPersons() {
		List<Person> persons=this.getHibernateTemplate().find("from Person");
		return persons;
	}

}
