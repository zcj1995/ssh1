package com.etc.dao;

import java.util.List;

import com.etc.entity.Person;

public interface IPersonDao {
	public int add(Person user);

	public void update(Person user);

	public void delete(int index);

	public Person getPerson(int index);

	public List<Person> getPersons();
}
