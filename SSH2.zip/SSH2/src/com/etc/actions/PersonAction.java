package com.etc.actions;

import java.util.ArrayList;
import java.util.List;

import com.etc.entity.Person;
import com.etc.service.IPersonService;
import com.etc.service.imp.PersonServiceImp;
import com.opensymphony.xwork2.ActionSupport;

public class PersonAction extends ActionSupport {

	private IPersonService personService;

	public IPersonService getPersonService() {
		return personService;
	}

	public void setPersonService(IPersonService personService) {
		this.personService = personService;
	}

	private List<Person> persons = new ArrayList<Person>();

	public List<Person> getPersons() {
		return persons;
	}

	public void setPersons(List<Person> persons) {
		this.persons = persons;
	}

	@Override
	public String execute() throws Exception {
		personService.add(new Person("zcj"));
		personService.add(new Person("cj"));
		personService.add(new Person("j"));
		personService.add(new Person("123"));
		return "success";

	}
}
