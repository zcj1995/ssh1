package com.etc.entity;

import java.io.Serializable;

public class Person implements Serializable {
	@Override
	public String toString() {
		return "Person [personid=" + personid + ", personname=" + personname
				+ "]";
	}

	private int personid;
	private String personname;
	public int getPersonid() {
		return personid;
	}
	public void setPersonid(int personid) {
		this.personid = personid;
	}
	public String getPersonname() {
		return personname;
	}
	public void setPersonname(String personname) {
		this.personname = personname;
	}
	
	public Person(int personid, String personname) {
		super();
		this.personid = personid;
		this.personname = personname;
	}
	public Person() {
		super();
	}
	public Person(String personname) {
		super();
		this.personname = personname;
	}
}
